<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>SDS | <?php echo e($judulHalaman); ?></title>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('logo.png')); ?>" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="diagnosa stunting, risna, tugas akhir, stunting, balita" name="keywords">
    <meta
        content="Sistem Diagnosa Stunting (SDS) merupakan web app yang dapat digunakan untuk melakukan diagnosa sementara pada anak yang memiliki beberapa ciri-ciri stunting."
        name="description">
    <?php echo $__env->make('layouts.landingpage.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!-- Spinner Start -->
    
    <!-- Spinner End -->


    <!-- Topbar Start -->
    
    <!-- Topbar End -->


    <!-- Brand Start -->
    <div class="container-fluid bg-primary text-white pt-4 pb-5 d-none d-lg-flex">
        <div class="container pb-2">
            <div class="d-flex align-items-center justify-content-between">
                <div class="d-flex">
                    <i class="bi bi-telephone-inbound fs-2"></i>
                    <div class="ms-3">
                        <h5 class="text-white mb-0">Hubungi Sekarang</h5>
                        <span>0852-9323-8822 </span>
                    </div>
                </div>
                <a href="<?php echo e(url('/')); ?>" class="h1 text-white mb-0">
                <img src="<?php echo e(asset('logo.png')); ?>" width="60" alt="">
                <span>SDS</span>
                </a>
                <div class="d-flex">
                    <i class="bi bi-envelope fs-2"></i>
                    <div class="ms-3">
                        <h5 class="text-white mb-0">Email Sekarang</h5>
                        <span>risna@gmail.com</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Brand End -->


    <!-- Navbar Start -->
    <?php echo $__env->make('layouts.landingpage.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navbar End -->

    <?php echo $__env->yieldContent('pages'); ?>


    <!-- Footer Start -->
    <?php echo $__env->make('layouts.landingpage.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer End -->


    <!-- Copyright Start -->
    <?php echo $__env->make('layouts.landingpage.copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Copyright End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i
            class="bi bi-arrow-up"></i></a>


    <?php echo $__env->make('layouts.landingpage.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\Project\Risna\stunting\resources\views/layouts/landingpage.blade.php ENDPATH**/ ?>