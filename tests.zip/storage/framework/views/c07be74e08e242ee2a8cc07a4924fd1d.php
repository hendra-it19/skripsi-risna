

<?php $__env->startSection('pages'); ?>
    <div class="row mt-5 gap-5">
        <div class="card shadow col-4 col-md-3 col-lg-2 text-center py-3">
            <h6>Jumlah Pengguna</h6>
            <hr>
            <h4><?php echo e($user); ?></h4>
        </div>
        <div class="card shadow col-4 col-md-3 col-lg-2 text-center py-3">
            <h6>Diagnosa Positif</h6>
            <hr>
            <h4><?php echo e($hasilPerhitunganPositif); ?></h4>
        </div>
        <div class="card shadow col-4 col-md-3 col-lg-2 text-center py-3">
            <h6>Diagnosa Negatif</h6>
            <hr>
            <h4><?php echo e($hasilPerhitunganNegatif); ?></h4>
        </div>
        <div class="card shadow col-4 col-md-3 col-lg-2 text-center py-3">
            <h6>Total Riwayat</h6>
            <hr>
            <h4><?php echo e($hasilPerhitunganPositif + $hasilPerhitunganNegatif); ?></h4>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Risna - Diagnosa Stunting\stunting\resources\views/pages/dashboardpage/utama.blade.php ENDPATH**/ ?>