<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SDS Dashboard | <?php echo e($judulHalaman); ?></title>
    <link rel="shortcut icon" type="image/jpeg" href="<?php echo e(asset('logo.jpeg')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('dashboardpage/assets/css/styles.min.css')); ?>" />
</head>

<body>
    <!--  Body Wrapper -->
    <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed">
        <!-- Sidebar Start -->
        <?php echo $__env->make('layouts.dashboardpage.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--  Sidebar End -->
        <!--  Main wrapper -->
        <div class="body-wrapper">
            <!--  Header Start -->
            <?php echo $__env->make('layouts.dashboardpage.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--  Header End -->
            <div class="container-fluid" >
                <!--  Row 1 -->

                <?php echo $__env->yieldContent('pages'); ?>

                
            </div>
        </div>
    </div>


    <?php echo $__env->make('layouts.dashboardpage.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\Project\Risna\stanting\resources\views/layouts/dashboardpage.blade.php ENDPATH**/ ?>