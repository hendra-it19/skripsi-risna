

<?php $__env->startSection('pages'); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Silahkan isi data anda dengan benar!</h5>
            <hr class="mb-4">

            <form action="<?php echo e(route('hasil-perhitungan.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <div class="row">
                    <div class="form-group mb-3 col-12 col-md-5">
                        <label for="nama">Nama lengkap</label>
                        <input type="text" id="nama" name="nama"
                            class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('nama')); ?>">
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3 col-12 col-md-5">
                        <label for="umur">Umur (bulan)</label>
                        <select name="umur" id="umur"
                            class="form-select <?php $__errorArgs = ['umur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            is-invalid
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Pilih range umur</option>
                            <?php $__currentLoopData = $umur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->umur); ?>">
                                    <?php echo e($row->umur); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['umur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3 col-12 col-md-5">
                        <label for="jenis_kelamin">Jenis kelamin</label>
                        <select name="jenis_kelamin" id="jenis_kelamin"
                            class="form-select <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Pilih jenis kelamin</option>
                            <?php $__currentLoopData = $jenisKelamin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>">
                                    [<?php echo e($row->kode); ?>] <?php echo e($row->jenis_kelamin); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3 col-12 col-md-5">
                        <label for="tinggi_badan">Tinggi Badan (cm)</label>
                        <select name="tinggi_badan" id="tinggi_badan"
                            class="form-select <?php $__errorArgs = ['tinggi_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            disabled>
                            <option value="">Pilih tinggi badan</option>
                        </select>
                        <?php $__errorArgs = ['tinggi_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3 col-12 col-md-5">
                        <label for="ciri_fisik">Ciri fisik</label>
                        <select name="ciri_fisik" id="ciri_fisik"
                            class="form-select <?php $__errorArgs = ['ciri_fisik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Pilih ciri fisik</option>
                            <?php $__currentLoopData = $ciriFisik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>" <?php if(old('ciri_fisik') == $row->id): ?> selected <?php endif; ?>>
                                    [<?php echo e($row->kode); ?>] <?php echo e($row->ciri_fisik); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['ciri_fisik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="btn-group d-flex mt-4">
                    <button class="btn btn-outline-danger" type="reset">Hapus data</button>
                    <button class="btn btn-primary" type="submit">Proses Data</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

            let umur = $('#umur');
            let jenis_kelamin = $('#jenis_kelamin');
            let val_umur = null;
            let val_kelamin = null;
            let data = null;

            umur.on('change', function($event) {
                val_umur = $event.target.value;
                val_kelamin = jenis_kelamin.val();
                ubah(val_umur, val_kelamin);
            })

            jenis_kelamin.on('change', function($event) {
                val_umur = umur.val();
                val_kelamin = $event.target.value;
                ubah(val_umur, val_kelamin);
            })

            function ubah(u, k) {
                if (u != '' && k != '') {
                    $('#tinggi_badan').removeAttr('disabled');
                    $.get('/user/hasil-perhitungan/get-data?jenis_kelamin=' + k + '&umur=' + u + '',
                        function(data, status) {
                            let select = $('#tinggi_badan');
                            select.empty();
                            select.append(`<option value="">Pilih tinggi badan</option>`);
                            $.each(data.data, function(index, value) {
                                select.append(
                                    `<option value="${value.id}">${value.tinggi_badan} cm</option>`);
                            })
                        }
                    );
                } else {
                    $('#tinggi_badan').attr('disabled', 'disabled');
                    $('#tinggi_badan').val() = '';
                    $('#tinggi_badan').empty();
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Risna\stunting\resources\views/pages/dashboardpage/diagnosa/create.blade.php ENDPATH**/ ?>