  <script src="<?php echo e(asset('dashboardpage/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboardpage/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboardpage/assets/js/sidebarmenu.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboardpage/assets/js/app.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboardpage/assets/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboardpage/assets/libs/simplebar/dist/simplebar.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboardpage/assets/js/dashboard.js')); ?>"></script>
<?php /**PATH D:\Project\Risna\stanting\resources\views/layouts/dashboardpage/script.blade.php ENDPATH**/ ?>