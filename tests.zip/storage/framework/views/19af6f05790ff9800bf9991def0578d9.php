

<?php $__env->startSection('pages'); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Sample Page</h5>
            <p class="mb-0">Ciri Fisik</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Risna\stanting\resources\views/pages/dashboardpage/master/ciri_fisik/index.blade.php ENDPATH**/ ?>