

<?php $__env->startSection('pages'); ?>
    <div class="card">
        <div class="card-body">

            <div class="d-flex justify-content-between mb-5 mt-2">
                <div class="d-inline-block">
                    <h3 class="mb-4">Manajemen Pengguna</h3>
                </div>
                <div class="d-inline-block">
                    
                </div>
            </div>


            <div>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-info">
                        <?php echo e($message); ?>

                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('errors')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                <?php endif; ?>

                <table class="table" id="table" data-order='[[ 1, "asc" ]]' data-page-length='10'>
                    <thead>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($row->nama); ?></td>
                                <td><?php echo e($row->email); ?></td>
                                <td>
                                    <?php if($row->role == 'admin'): ?>
                                        <span class="btn btn-sm btn-danger">Admin</span>
                                    <?php else: ?>
                                        <span class="btn btn-sm btn-success">Pengguna</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($row->role == 'admin'): ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" disabled>Hapus</button>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('manajemen-pengguna.destroy', $row->id)); ?>" method="post"
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" onclick="return confirm('Yakin ingin menghapus data?')"
                                                class="btn btn-sm btn-outline-danger">Hapus</button>
                                        </form>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('manajemen-pengguna.edit', $row->id)); ?>"
                                        class="btn btn-sm btn-outline-warning">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Risna\stunting\resources\views/pages/dashboardpage/pengguna/index.blade.php ENDPATH**/ ?>