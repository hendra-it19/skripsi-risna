

<?php $__env->startSection('pages'); ?>
    <div class="card">
        <div class="card-body">

            <div class="d-flex justify-content-between mb-5 mt-2">
                <div class="d-inline-block">
                    <h3 class="mb-4">Tinggi Badan</h3>
                </div>
                <div class="d-inline-block">
                    <a href="<?php echo e(route('tinggi-badan.create')); ?>" class="btn btn-outline-primary">Tambah data</a>
                </div>
            </div>


            <div>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-info">
                        <?php echo e($message); ?>

                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('errors')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                <?php endif; ?>

                <table class="table" id="table" data-order='[[ 1, "asc" ]]' data-page-length='10'>
                    <thead>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Umur (Bulan)</th>
                        <th>Jenis Kelamin</th>
                        <th>Tinggi Badan</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($row->kode); ?></td>
                                <td><?php echo e($row->umur); ?></td>
                                <td><?php echo e($row->jenisKelamin->jenis_kelamin); ?></td>
                                <td> <?php echo e($row->tinggi_badan); ?></td>
                                <td>
                                    <form action="<?php echo e(route('tinggi-badan.destroy', $row->id)); ?>" method="post"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" onclick="return confirm('Yakin ingin menghapus data?')"
                                            class="btn btn-sm btn-outline-danger">Hapus</button>
                                    </form>
                                    <a href="<?php echo e(route('tinggi-badan.edit', $row->id)); ?>"
                                        class="btn btn-sm btn-outline-warning">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Risna - Diagnosa Stunting\stunting\resources\views/pages/dashboardpage/master/tinggi_badan/index.blade.php ENDPATH**/ ?>