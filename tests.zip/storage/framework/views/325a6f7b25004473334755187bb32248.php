    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('landingpage/lib/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landingpage/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landingpage/lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landingpage/lib/counterup/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('landingpage/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('landingpage/js/main.js')); ?>"></script>
<?php /**PATH D:\Project\Risna\stanting\resources\views/layouts/landingpage/script.blade.php ENDPATH**/ ?>