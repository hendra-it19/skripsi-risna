    <aside class="left-sidebar">
        <!-- Sidebar scroll-->
        <div>
            <div class="brand-logo d-flex align-items-center justify-content-center py-3">
                <a href="<?php echo e(url('/dashboard')); ?>" class="text-nowrap logo-img text-center">
                    <img src="<?php echo e(asset('logo.png')); ?>" width="70" alt="logo" class="text-center" />
                </a>
                <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
                    <i class="ti ti-x fs-8"></i>
                </div>
            </div>
            <!-- Sidebar navigation-->
            <nav class="sidebar-nav scroll-sidebar" data-simplebar="">
                <ul id="sidebarnav">
                    <li class="nav-small-cap">
                        <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                        <span class="hide-menu">Utama</span>
                    </li>
                    <li class="sidebar-item">
                        <a class="sidebar-link" href="<?php echo e(url('/dashboard')); ?>" aria-expanded="false">
                            <span>
                                <i class="ti ti-layout-dashboard"></i>
                            </span>
                            <span class="hide-menu">Dashboard</span>
                        </a>
                    </li>

                    
                    <?php if(auth()->user()->role == 'admin'): ?>
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Master Data</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link <?php if($judulHalaman == 'Master - Jenis Kelamin'): ?> active <?php endif; ?>"
                                href="<?php echo e(route('jenis-kelamin.index')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-gender-bigender"></i>
                                </span>
                                <span class="hide-menu">Jenis Kelamin</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link <?php if($judulHalaman == 'Master - Tinggi Badan'): ?> active <?php endif; ?>"
                                href="<?php echo e(route('tinggi-badan.index')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-chart-arrows-vertical"></i>
                                </span>
                                <span class="hide-menu">Tinggi Badan</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link <?php if($judulHalaman == 'Master - Ciri Fisik'): ?> active <?php endif; ?>"
                                href="<?php echo e(route('ciri-fisik.index')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-stretching"></i>
                                </span>
                                <span class="hide-menu">Ciri Fisik</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link <?php if($judulHalaman == 'Master - Hasil Diagnosa'): ?>  <?php endif; ?>"
                                href="<?php echo e(route('hasil-diagnosa.index')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-heart-rate-monitor"></i>
                                </span>
                                <span class="hide-menu">Hasil Diagnosa</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link <?php if($judulHalaman == 'Master - Solusi Stunting'): ?> active <?php endif; ?>"
                                href="<?php echo e(route('solusi-stunting.index')); ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-stethoscope"></i>
                                </span>
                                <span class="hide-menu">Solusi Stunting</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    
                    <li class="nav-small-cap">
                        <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                        <span class="hide-menu">Diagnosa</span>
                    </li>
                    <li class="sidebar-item">
                        <a class="sidebar-link <?php if($judulHalaman == 'Diagnosa - Input'): ?> active <?php endif; ?>"
                            href="<?php echo e(route('hasil-perhitungan.create')); ?>" aria-expanded="false">
                            <span>
                                <i class="ti ti-keyboard"></i>
                            </span>
                            <span class="hide-menu">Input</span>
                        </a>
                    </li>
                    <li class="sidebar-item">
                        <a class="sidebar-link <?php if($judulHalaman == 'Diagnosa - Riwayat'): ?> active <?php endif; ?>"
                            href="<?php echo e(route('hasil-perhitungan.index')); ?>" aria-expanded="false">
                            <span>
                                <i class="ti ti-history"></i>
                            </span>
                            <span class="hide-menu">Riwayat</span>
                        </a>
                    </li>


                    
                    <?php if(auth()->user()->role == 'admin'): ?>
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Manajemen</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="<?php echo e(route('manajemen-pengguna.index')); ?>"
                                aria-expanded="false">
                                <span>
                                    <i class="ti ti-user"></i>
                                </span>
                                <span class="hide-menu">Pengguna</span>
                            </a>
                        </li>
                    <?php endif; ?>


                </ul>

                
                <form action="<?php echo e(route('auth.logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger mb-5 mt-3" style="width: 100%"
                        onclick="return confirm('Yakin ingin keluar?')">Logout</button>
                </form>
            </nav>
            <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
    </aside>
<?php /**PATH D:\Project\Risna - Diagnosa Stunting\stunting\resources\views/layouts/dashboardpage/sidebar.blade.php ENDPATH**/ ?>