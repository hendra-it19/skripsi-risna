

<?php $__env->startSection('pages'); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Data anda berhasil dianalisis</h5>
            <hr class="mb-4">

            <div class="row">
                <table class="table border">
                    <thead>
                        <th>
                            Nama Lengkap
                        </th>
                        <th>
                            Umur
                        </th>
                        <th>
                            Jenis Kelamin
                        </th>
                        <th>
                            Tinggi Badan
                        </th>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($hasilPerhitungan->nama); ?></td>
                            <td><?php echo e($hasilPerhitungan->umur); ?> Bulan</td>
                            <td><?php echo e($hasilPerhitungan->jenisKelamin->jenis_kelamin); ?></td>
                            <td><?php echo e($hasilPerhitungan->tinggiBadan->tinggi_badan); ?> cm</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="row mt-3">
                <h5>Diagnosa data pasien dengan metode forward chaining</h5>

                <ol class="mx-3">
                    <li>Variabel 1 yaitu jenis kelamin yang disimbolkan dengan A dengan nilai :
                        <?php echo e($hasilPerhitungan->jenisKelamin->kode); ?></li>
                    <li>Variabel 2 yaitu tinggi badan yang disimbolkan dengan B dengan nilai :
                        <?php echo e($hasilPerhitungan->tinggiBadan->kode); ?></li>
                    <li>Variabel 3 yaitu ciri fisik yang disimbolkan dengan C dengan nilai :
                        <?php echo e($hasilPerhitungan->ciriFisik->kode); ?></li>
                </ol>

                <p>Kemudian, dengan varibel ke-4 sebagai hasil diagnosa pasien dengan nilai
                    <?php echo e($hasilPerhitungan->hasilDiagnosa->kode); ?> atau dengan hasil ini memberikan diagnosa sementara bahwa
                    pasien mendapatkan hasil <strong><?php echo $hasilPerhitungan->hasilDiagnosa->kode == 'D1'
                        ? '<span class="text-danger">Positif Stunting</span>'
                        : '<span class="text-success">Negatif</span>'; ?></strong></p>

                <p>Dengan hasil di atas, maka pasien dapat diberikan beberapa tindakan
                    <strong>
                        <?php if($hasilPerhitungan->hasilDiagnosa->kode == 'D1'): ?>
                            Pengobatan
                        <?php else: ?>
                            Pencegahan stunting
                        <?php endif; ?>
                    </strong> sebagai berikut :</p>
                <div>
                    <?php echo $hasilPerhitungan->solusiStunting->solusi_stunting; ?>

                </div>
                <div class="d-flex flex-column">
                    <a href="<?php echo e(route('hasil-perhitungan.create')); ?>" class="btn btn-primary mt-3">Kembali ke form pengisian</a>
                    <a href="<?php echo e(route('hasil-perhitungan.index')); ?>" class="text-center my-3">Lihat daftar riwayat</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Risna\stunting\resources\views/pages/dashboardpage/diagnosa/show.blade.php ENDPATH**/ ?>