@extends('layouts.dashboardpage')

@section('pages')
    <div class="card">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-4">Sample Page</h5>
            <p class="mb-0">Jenis Kelamin</p>
        </div>
    </div>
@endsection
